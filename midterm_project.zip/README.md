# Mobile Programming – Midterm Projects

## Student Information
- **Name:** Tarık Buğra Koca
- **Student ID:** 220408030
- **GitHub Repository:** https://github.com/TarikBugraKoca/Works

## Project Structure
quick-quiz/
simple-gallery/
README.md
