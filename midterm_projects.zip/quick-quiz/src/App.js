import React, { useState } from "react";
import { QUESTIONS } from "./questions";
import QuestionCard from "./components/QuestionCard";
import ResultsScreen from "./components/ResultsScreen";
import "./App.css";

function App() {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);

  const isQuizFinished = currentQuestionIndex >= QUESTIONS.length;

  const handleAnswerClick = (selectedOption) => {
    const currentQuestion = QUESTIONS[currentQuestionIndex];

    if (selectedOption === currentQuestion.correctAnswer) {
      setScore((prevScore) => prevScore + 1);
    }

    setCurrentQuestionIndex((prevIndex) => prevIndex + 1);
  };

  const handleRestart = () => {
    setCurrentQuestionIndex(0);
    setScore(0);
  };

  return (
    <div className="app">
      <h1 className="title">React Quiz App</h1>
      {!isQuizFinished ? (
        <QuestionCard
          question={QUESTIONS[currentQuestionIndex]}
          onAnswerClick={handleAnswerClick}
        />
      ) : (
        <ResultsScreen
          score={score}
          totalQuestions={QUESTIONS.length}
          onRestart={handleRestart}
        />
      )}
    </div>
  );
}

export default App;
