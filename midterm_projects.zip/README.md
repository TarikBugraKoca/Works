# Mobile Programming 2025 – Midterm Projects

## Student Information
- Name: YOUR_NAME_HERE
- Student ID: YOUR_STUDENT_ID_HERE
- GitHub Repository: https://github.com/YOUR_USERNAME/YOUR_REPO_NAME

## Project Structure

- `quick-quiz/` – React JS Quiz App
- `simple-gallery/` – React Native Simple Gallery App
